o nosso prototipo foi testado no Mozilla Firefox apenas, em principio funciona em todos os browsers.
Tenham aten��o que o prototipo inclui 2 faixas de musica (de forma a usar a funcionalidade MUTE).
� recomendado o uso de phones e aten��o ao volume do som para n�o causar sustos.
Caso n�o se esteja a ouvir som algum � recomendado o uso do browser Mozilla Firefox, as faixas est�o em formato
.ogg mas nunca se sabe...
Atenciosamente Grupo 1T